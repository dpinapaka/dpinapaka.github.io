import type { Occurrence, ScheduleItem } from '../types'

export const MINUTE = 60_000
export const HOUR = 60 * MINUTE

export function pad(n: number) {
  return String(n).padStart(2, '0')
}

export function ymd(d: Date) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}

/** Parse YYYY-MM-DD + HH:MM as a local Date (never UTC-shifted). */
export function parseLocal(date: string, time: string) {
  const [y, m, d] = date.split('-').map(Number)
  const [hh, mm] = time.split(':').map(Number)
  return new Date(y, (m || 1) - 1, d || 1, hh || 0, mm || 0, 0, 0)
}

export function startOfDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0)
}

export function addDays(d: Date, n: number) {
  const copy = new Date(d)
  copy.setDate(copy.getDate() + n)
  return copy
}

export function sameDay(a: Date, b: Date) {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  )
}

function matchesRepeat(item: ScheduleItem, day: Date) {
  const startDay = parseLocal(item.date, '00:00')
  if (startOfDay(day).getTime() < startDay.getTime()) return false
  switch (item.repeat) {
    case 'once':
      return sameDay(day, startDay)
    case 'daily':
      return true
    case 'weekdays': {
      const wd = day.getDay()
      return wd >= 1 && wd <= 5
    }
    case 'weekly':
      return day.getDay() === startDay.getDay()
  }
}

/** Every occurrence whose start falls between two dates. */
export function occurrencesBetween(
  items: ScheduleItem[],
  from: Date,
  to: Date,
): Occurrence[] {
  const out: Occurrence[] = []
  const first = startOfDay(from)
  const last = startOfDay(to)
  for (let day = first; day.getTime() <= last.getTime(); day = addDays(day, 1)) {
    for (const item of items) {
      if (!matchesRepeat(item, day)) continue
      const start = parseLocal(ymd(day), item.time)
      if (start < from || start > to) continue
      out.push({
        item,
        key: `${item.id}|${ymd(day)}`,
        date: ymd(day),
        start,
        end: new Date(start.getTime() + item.duration * MINUTE),
        trigger: new Date(start.getTime() - item.lead * MINUTE),
      })
    }
  }
  return out.sort((a, b) => a.start.getTime() - b.start.getTime())
}

/** Occurrences starting in the next `days` days, including those already running. */
export function upcoming(items: ScheduleItem[], now: Date, days = 14) {
  const from = new Date(now.getTime() - HOUR * 12)
  return occurrencesBetween(items, from, addDays(now, days))
}

export function nextOccurrence(items: ScheduleItem[], now: Date) {
  // Include yesterday so an occurrence that crosses midnight can remain in
  // the Next Up card until it ends. The form's longest supported duration is
  // two hours, so a 24-hour lookback safely covers active items.
  const from = new Date(now.getTime() - 24 * HOUR)
  return (
    occurrencesBetween(items, from, addDays(now, 14)).find(
      (occurrence) => occurrence.end.getTime() > now.getTime(),
    ) ?? null
  )
}

/** Reminders whose trigger time has arrived inside the grace window. */
export function dueReminders(
  items: ScheduleItem[],
  now: Date,
  grace = 5 * MINUTE,
): Occurrence[] {
  const from = new Date(now.getTime() - grace)
  const horizon = new Date(now.getTime() + 4 * HOUR)
  return occurrencesBetween(items, from, horizon).filter(
    (o) => o.trigger >= from && o.trigger <= now,
  )
}

export function fmtTime(d: Date) {
  const h = d.getHours()
  const m = d.getMinutes()
  const suffix = h < 12 ? 'am' : 'pm'
  const hour12 = h % 12 === 0 ? 12 : h % 12
  return `${hour12}:${pad(m)} ${suffix}`
}

export function fmtDuration(minutes: number) {
  if (minutes < 60) return `${minutes} min`
  const h = Math.floor(minutes / 60)
  const m = minutes % 60
  return m === 0 ? `${h} hr` : `${h} hr ${m} min`
}

export function fmtLead(minutes: number) {
  if (minutes === 0) return 'At start time'
  return `${fmtDuration(minutes)} before`
}

/** 1h 04m / 12m 05s — countdown text. */
export function fmtCountdown(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000))
  const h = Math.floor(total / 3600)
  const m = Math.floor((total % 3600) / 60)
  const s = total % 60
  if (h >= 24) {
    const days = Math.floor(h / 24)
    return `${days}d ${h % 24}h`
  }
  if (h > 0) return `${h}h ${pad(m)}m`
  return `${m}m ${pad(s)}s`
}

export function dayHeading(date: Date, now: Date) {
  const diff = Math.round(
    (startOfDay(date).getTime() - startOfDay(now).getTime()) / (24 * HOUR),
  )
  if (diff === 0) return 'Today'
  if (diff === 1) return 'Tomorrow'
  if (diff === -1) return 'Yesterday'
  return date.toLocaleDateString(undefined, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  })
}

export function shortDay(date: Date) {
  return date.toLocaleDateString(undefined, { weekday: 'short' })
}
