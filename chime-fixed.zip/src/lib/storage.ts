import type { ScheduleItem, Settings, Tag } from '../types'
import { addDays, ymd } from './schedule'

const ITEMS_KEY = 'chime.items.v1'
const FIRED_KEY = 'chime.fired.v1'
const SNOOZE_KEY = 'chime.snoozes.v1'
const SETTINGS_KEY = 'chime.settings.v1'

export type Snooze = {
  id: string
  title: string
  note: string
  tag: Tag
  at: number
}

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return fallback
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    // storage full or blocked — the app keeps working for this session
  }
}

function uid() {
  return `it_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`
}

export function makeId() {
  return uid()
}

export function loadItems(): ScheduleItem[] {
  const stored = read<ScheduleItem[] | null>(ITEMS_KEY, null)
  if (stored) return stored
  const seeds = seedItems()
  write(ITEMS_KEY, seeds)
  return seeds
}

export function saveItems(items: ScheduleItem[]) {
  write(ITEMS_KEY, items)
}

export function loadSettings(): Settings {
  return read<Settings>(SETTINGS_KEY, { sound: true })
}

export function saveSettings(settings: Settings) {
  write(SETTINGS_KEY, settings)
}

export function loadFired(): string[] {
  return read<string[]>(FIRED_KEY, [])
}

export function saveFired(keys: string[]) {
  write(FIRED_KEY, keys.slice(-400))
}

export function loadSnoozes(): Snooze[] {
  return read<Snooze[]>(SNOOZE_KEY, []).filter((s) => s.at > Date.now() - 864e5)
}

export function saveSnoozes(list: Snooze[]) {
  write(SNOOZE_KEY, list)
}

function seedItems(): ScheduleItem[] {
  const now = new Date()
  // Next round half-hour, but never in the small hours.
  const start = new Date(now.getTime() + 90 * 60_000)
  start.setMinutes(start.getMinutes() < 30 ? 30 : 0, 0, 0)
  if (start.getMinutes() === 0) start.setHours(start.getHours() + 1)
  if (start.getHours() < 8) start.setHours(9, 0, 0, 0)
  const tomorrow = addDays(now, 1)
  const two = (n: number) => String(n).padStart(2, '0')
  return [
    {
      id: uid(),
      title: 'Try a reminder',
      note: 'This example will pop up on your desktop. Allow notifications first.',
      date: ymd(now),
      time: `${two(start.getHours())}:${two(start.getMinutes())}`,
      duration: 15,
      repeat: 'once',
      lead: 0,
      tag: 'signal',
      createdAt: Date.now(),
      demo: true,
    },
    {
      id: uid(),
      title: 'Plan the week',
      note: 'Half an hour with a blank page and the calendar.',
      date: ymd(tomorrow),
      time: '09:00',
      duration: 30,
      repeat: 'weekly',
      lead: 10,
      tag: 'sky',
      createdAt: Date.now(),
      demo: true,
    },
  ]
}
