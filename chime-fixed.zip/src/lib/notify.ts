import type { Occurrence } from '../types'
import { fmtTime } from './schedule'

export type Permission = 'default' | 'granted' | 'denied' | 'unsupported'

export function notificationPermission(): Permission {
  if (typeof Notification === 'undefined') return 'unsupported'
  return Notification.permission as Permission
}

export async function askForNotifications(): Promise<Permission> {
  if (typeof Notification === 'undefined') return 'unsupported'
  if (Notification.permission !== 'default') {
    return Notification.permission as Permission
  }
  try {
    const result = await Notification.requestPermission()
    return result as Permission
  } catch {
    return 'denied'
  }
}

let audio: AudioContext | null = null

/** Two soft bell notes — audible even when notification sound is off at OS level. */
export function playChime() {
  try {
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext
    if (!Ctor) return
    audio ??= new Ctor()
    if (audio.state === 'suspended') void audio.resume()
    const now = audio.currentTime
    const notes = [
      { f: 880, t: 0 },
      { f: 1174.66, t: 0.18 },
      { f: 1318.51, t: 0.36 },
    ]
    for (const { f, t } of notes) {
      const osc = audio.createOscillator()
      const gain = audio.createGain()
      osc.type = 'sine'
      osc.frequency.value = f
      gain.gain.setValueAtTime(0, now + t)
      gain.gain.linearRampToValueAtTime(0.12, now + t + 0.02)
      gain.gain.exponentialRampToValueAtTime(0.0001, now + t + 0.9)
      osc.connect(gain).connect(audio.destination)
      osc.start(now + t)
      osc.stop(now + t + 1)
    }
  } catch {
    // audio is a nicety; never block the reminder
  }
}

let registration: ServiceWorkerRegistration | null = null

export function registerWorker() {
  if (!('serviceWorker' in navigator) || !window.isSecureContext) return

  // Resolve from the document URL so this also works when the app is hosted
  // below the domain root (for example, /tools/chime/).
  const workerUrl = new URL('sw.js', document.baseURI)
  navigator.serviceWorker
    .register(workerUrl)
    .then((reg) => {
      registration = reg
    })
    .catch(() => {
      // Notifications can still use the browser constructor when permitted.
    })
}

export async function showReminder(o: Occurrence) {
  const title = o.item.title
  const body = `${fmtTime(o.start)}${o.item.note ? ` — ${o.item.note}` : ''}`
  const icon = new URL('icons/icon-192.png', document.baseURI).href
  const tag = o.key
  try {
    if (registration?.active) {
      await registration.showNotification(title, {
        body,
        tag,
        icon,
        badge: icon,
        requireInteraction: true,
        data: { key: o.key },
      })
      return
    }
  } catch {
    // fall through to the constructor
  }
  try {
    if (notificationPermission() === 'granted') {
      new Notification(title, { body, tag, icon, requireInteraction: true })
    }
  } catch {
    // Some browsers only allow notifications from the service worker.
  }
}

export async function showSnooze(title: string, note: string) {
  const body = note || 'Snoozed reminder'
  try {
    if (registration?.active) {
      await registration.showNotification(title, {
        body,
        tag: `snooze-${Date.now()}`,
        icon: new URL('icons/icon-192.png', document.baseURI).href,
      })
    } else if (notificationPermission() === 'granted') {
      new Notification(title, { body })
    }
  } catch {
    // ignore
  }
}
