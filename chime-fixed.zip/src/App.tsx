import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { Occurrence, ScheduleItem, Settings } from './types'
import { REPEAT_LABEL } from './types'
import {
  HOUR,
  MINUTE,
  addDays,
  dayHeading,
  dueReminders,
  fmtLead,
  fmtTime,
  nextOccurrence,
  occurrencesBetween,
  parseLocal,
  sameDay,
  shortDay,
  startOfDay,
  ymd,
} from './lib/schedule'
import {
  loadFired,
  loadItems,
  loadSettings,
  loadSnoozes,
  makeId,
  saveFired,
  saveItems,
  saveSettings,
  saveSnoozes,
  type Snooze,
} from './lib/storage'
import {
  askForNotifications,
  notificationPermission,
  playChime,
  registerWorker,
  showReminder,
  showSnooze,
  type Permission,
} from './lib/notify'
import { NextUp, TagDot } from './components/NextUp'
import { ReminderForm } from './components/ReminderForm'

type Toast = { id: string; title: string; body: string }

function blankItem(): ScheduleItem {
  const now = new Date()
  // Next half hour, always at least an hour ahead so it is not instantly past.
  const next = new Date(now.getTime() + HOUR)
  next.setSeconds(0, 0)
  next.setMinutes(next.getMinutes() < 30 ? 30 : 0)
  if (next.getMinutes() === 0) next.setHours(next.getHours() + 1)
  return {
    id: makeId(),
    title: '',
    note: '',
    date: ymd(next),
    time: `${String(next.getHours()).padStart(2, '0')}:${String(next.getMinutes()).padStart(2, '0')}`,
    duration: 30,
    repeat: 'once',
    lead: 10,
    tag: 'signal',
    createdAt: Date.now(),
  }
}

export default function App() {
  const [items, setItems] = useState<ScheduleItem[]>(() => loadItems())
  const [settings, setSettings] = useState<Settings>(() => loadSettings())
  const [now, setNow] = useState(() => new Date())
  const [fired, setFired] = useState<string[]>(() => loadFired())
  const [snoozes, setSnoozes] = useState<Snooze[]>(() => loadSnoozes())
  const [permission, setPermission] = useState<Permission>(() =>
    notificationPermission(),
  )
  const [draft, setDraft] = useState<ScheduleItem | null>(null)
  const [isNew, setIsNew] = useState(true)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [toasts, setToasts] = useState<Toast[]>([])
  const [installPrompt, setInstallPrompt] = useState<
    (Event & { prompt: () => Promise<void> }) | null
  >(null)
  const [showAll, setShowAll] = useState(false)
  const dialogRef = useRef<HTMLDialogElement>(null)
  const lastCheckRef = useRef(0)

  useEffect(() => {
    registerWorker()
  }, [])

  useEffect(() => {
    saveItems(items)
  }, [items])
  useEffect(() => {
    saveSettings(settings)
  }, [settings])
  useEffect(() => {
    saveFired(fired)
  }, [fired])
  useEffect(() => {
    saveSnoozes(snoozes)
  }, [snoozes])

  // persistent local ticker
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000)
    return () => window.clearInterval(id)
  }, [])

  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible') setNow(new Date())
    }
    document.addEventListener('visibilitychange', onVisible)
    return () => document.removeEventListener('visibilitychange', onVisible)
  }, [])

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault()
      setInstallPrompt(e as Event & { prompt: () => Promise<void> })
    }
    window.addEventListener('beforeinstallprompt', handler)
    return () => window.removeEventListener('beforeinstallprompt', handler)
  }, [])

  const pushToast = useCallback((title: string, body: string) => {
    const id = makeId()
    setToasts((prev) => [...prev, { id, title, body }].slice(-3))
    window.setTimeout(
      () => setToasts((prev) => prev.filter((t) => t.id !== id)),
      9000,
    )
  }, [])

  // reminder engine: alarm-schedule catch-up every 15s, plus instant on focus
  const checkDue = useCallback(
    (at: Date) => {
      const stamp = at.getTime()
      if (stamp - lastCheckRef.current < 10_000) return
      lastCheckRef.current = stamp
      const due = dueReminders(items, at, minutes(15)).filter(
        (o) => !fired.includes(o.key),
      )
      if (due.length) {
        setFired((prev) => [...prev, ...due.map((o) => o.key)].slice(-400))
        for (const o of due) {
          void showReminder(o)
          pushToast(
            o.item.title,
            `${fmtTime(o.start)} · ${o.item.note || 'Scheduled reminder'}`,
          )
          if (settings.sound) playChime()
        }
      }

      const snoozeDue = snoozes.filter((s) => s.at <= stamp)
      if (snoozeDue.length) {
        setSnoozes((prev) => prev.filter((s) => s.at > stamp))
        for (const s of snoozeDue) {
          void showSnooze(s.title, s.note)
          pushToast(s.title, 'Snoozed reminder')
          if (settings.sound) playChime()
        }
      }
    },
    [items, fired, snoozes, settings.sound, pushToast],
  )

  useEffect(() => {
    checkDue(now)
  }, [now, checkDue])

  const next = useMemo(() => nextOccurrence(items, now), [items, now])
  const windowEnd = useMemo(() => addDays(startOfDay(now), 8), [now])
  const agenda = useMemo(() => {
    const all = occurrencesBetween(items, new Date(now.getTime() - 30 * MINUTE), windowEnd)
    return showAll ? all : all.slice(0, 40)
  }, [items, now, windowEnd, showAll])

  const groups = useMemo(() => {
    const map = new Map<string, Occurrence[]>()
    for (const occ of agenda) {
      const list = map.get(occ.date) ?? []
      list.push(occ)
      map.set(occ.date, list)
    }
    return [...map.entries()]
  }, [agenda])

  const todayCount = useMemo(
    () =>
      occurrencesBetween(items, startOfDay(now), addDays(startOfDay(now), 1)).length,
    [items, now],
  )

  const openNew = () => {
    setDraft(blankItem())
    setIsNew(true)
    dialogRef.current?.showModal()
  }

  const openEdit = (item: ScheduleItem) => {
    setDraft({ ...item })
    setIsNew(false)
    dialogRef.current?.showModal()
  }

  const closeDialog = () => {
    dialogRef.current?.close()
    setDraft(null)
  }

  const saveDraft = () => {
    if (!draft || !draft.title.trim()) return
    const cleaned = { ...draft, title: draft.title.trim(), note: draft.note.trim() }
    setItems((prev) =>
      isNew
        ? [...prev, cleaned]
        : prev.map((i) => (i.id === cleaned.id ? cleaned : i)),
    )
    closeDialog()
  }

  const deleteDraft = () => {
    if (!draft) return
    setItems((prev) => prev.filter((i) => i.id !== draft.id))
    closeDialog()
  }

  const enableNotifications = async () => {
    const result = await askForNotifications()
    setPermission(result)
    if (result === 'granted' && settings.sound) playChime()
  }

  const requestInstall = async () => {
    if (!installPrompt) return
    await installPrompt.prompt()
    setInstallPrompt(null)
  }

  const snoozeNext = () => {
    if (!next) return
    setSnoozes((prev) => [
      ...prev,
      {
        id: next.key,
        title: next.item.title,
        note: next.item.note,
        tag: next.item.tag,
        at: Date.now() + 5 * MINUTE,
      },
    ])
    pushToast(next.item.title, 'Snoozed for 5 minutes')
  }

  const today = now.toLocaleDateString(undefined, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  })

  return (
    <div className="app">
      <header className="masthead">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 24 24" width="17" height="17">
              <circle
                cx="12"
                cy="12"
                r="8.6"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.7"
              />
              <path
                d="M12 12V7.4"
                stroke="currentColor"
                strokeWidth="1.7"
                strokeLinecap="round"
              />
              <path
                d="M12 12l3.5 2.4"
                stroke="#d8380f"
                strokeWidth="1.9"
                strokeLinecap="round"
              />
            </svg>
          </span>
          <span className="brand-name">Chime</span>
        </div>
        <div className="masthead-right">
          <span className="today-date">{today}</span>
          <button
            className="icon-button"
            aria-label="Settings"
            aria-expanded={settingsOpen}
            onClick={() => setSettingsOpen((v) => !v)}
          >
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
              <path
                d="M4 7h9M17 7h3M4 17h3M11 17h9"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.75"
                strokeLinecap="round"
              />
              <circle cx="15" cy="7" r="2.4" fill="none" stroke="currentColor" strokeWidth="1.75" />
              <circle cx="9" cy="17" r="2.4" fill="none" stroke="currentColor" strokeWidth="1.75" />
            </svg>
          </button>
        </div>
      </header>

      {settingsOpen ? (
        <div className="settings">
          <div className="settings-head">
            <h2>Settings</h2>
            <button className="ghost small" onClick={() => setSettingsOpen(false)}>
              Done
            </button>
          </div>

          <div className="setting-row">
            <div>
              <p className="setting-title">Desktop alerts</p>
              <p className="setting-sub">{permissionCopy(permission)}</p>
            </div>
            {permission === 'granted' ? (
              <span className="badge-ok">On</span>
            ) : permission === 'unsupported' ? (
              <span className="badge-off">Unavailable</span>
            ) : permission === 'denied' ? (
              <span className="badge-off">Blocked</span>
            ) : (
              <button className="small primary" onClick={enableNotifications}>
                Allow
              </button>
            )}
          </div>

          <div className="setting-row">
            <div>
              <p className="setting-title">Chime sound</p>
              <p className="setting-sub">Three soft notes when a reminder fires.</p>
            </div>
            <button
              className={`switch ${settings.sound ? 'switch-on' : ''}`}
              role="switch"
              aria-checked={settings.sound}
              aria-label="Chime sound"
              onClick={() => {
                setSettings((s) => ({ ...s, sound: !s.sound }))
                if (!settings.sound) playChime()
              }}
            >
              <span />
            </button>
          </div>

          <div className="setting-row">
            <div>
              <p className="setting-title">Keep it on your desktop</p>
              <p className="setting-sub">
                Install Chime as its own window so reminders keep running.
              </p>
            </div>
            {installPrompt ? (
              <button className="small primary" onClick={requestInstall}>
                Install
              </button>
            ) : (
              <span className="setting-hint">
                {isStandalone() ? 'Installed' : 'Use your browser’s install option'}
              </span>
            )}
          </div>

          <button
            className="test-link"
            onClick={() => {
              pushToast('This is a test', 'Reminders look like this')
              if (permission === 'granted' && next) void showReminder(next)
              if (settings.sound) playChime()
            }}
          >
            Send a test alert
          </button>
        </div>
      ) : null}

      <main>
        {permission === 'default' || permission === 'denied' ? (
          <div className="permission-strip">
            <div className="permission-copy">
              <strong>
                {permission === 'denied'
                  ? 'Alerts are blocked in this browser'
                  : 'Turn on desktop alerts'}
              </strong>
              <span>
                {permission === 'denied'
                  ? 'Open your browser’s site settings for this page and allow notifications. Alerts still appear inside Chime.'
                  : 'Chime needs permission to pop reminders up over other windows.'}
              </span>
            </div>
            {permission === 'default' ? (
              <button className="primary small" onClick={enableNotifications}>
                Allow alerts
              </button>
            ) : null}
          </div>
        ) : null}

        {next ? (
          <NextUp occ={next} now={now} count={todayCount} />
        ) : (
          <section className="empty-ticket">
            <h2>Nothing scheduled in the next two weeks</h2>
            <p>Add a reminder and it will show up here with a live countdown.</p>
          </section>
        )}

        <div className="agenda-head">
          <h2>Coming up</h2>
          {next ? (
            <button className="ghost small" onClick={snoozeNext}>
              Snooze 5 min
            </button>
          ) : null}
        </div>

        {groups.length === 0 ? (
          <div className="empty-agenda">
            <p className="empty-lines" aria-hidden="true">
              <span />
              <span />
              <span />
            </p>
            <p>Your week is clear. Add the first reminder to fill this sheet.</p>
          </div>
        ) : (
          <div className="agenda">
            {groups.map(([date, list]) => {
              const d = parseLocal(date, '00:00')
              return (
                <section className="day" key={date}>
                  <div className={`day-label ${sameDay(d, now) ? 'is-today' : ''}`}>
                    <span className="day-name">{dayHeading(d, now)}</span>
                    <span className="day-short num">
                      {shortDay(d)} {String(d.getDate()).padStart(2, '0')}
                    </span>
                  </div>
                  <ol className="day-list">
                    {list.map((occ) => (
                      <li
                        key={occ.key}
                        className={`entry ${occ.start < now ? 'past' : ''}`}
                        data-tag={occ.item.tag}
                      >
                        <button
                          className="entry-button"
                          onClick={() => openEdit(occ.item)}
                          aria-label={`Edit ${occ.item.title}`}
                        >
                          <span className="entry-time num">{fmtTime(occ.start)}</span>
                          <span className="entry-rule" aria-hidden="true">
                            <TagDot tag={occ.item.tag} />
                          </span>
                          <span className="entry-body">
                            <span className="entry-title">{occ.item.title}</span>
                            <span className="entry-meta">
                              {occ.item.note ? `${occ.item.note} · ` : ''}
                              {REPEAT_LABEL[occ.item.repeat]} · {fmtLead(occ.item.lead)}
                            </span>
                          </span>
                          <span className="entry-arrow" aria-hidden="true">
                            Edit
                          </span>
                        </button>
                      </li>
                    ))}
                  </ol>
                </section>
              )
            })}
            {!showAll && agenda.length >= 40 ? (
              <button className="more" onClick={() => setShowAll(true)}>
                Show the rest of the week
              </button>
            ) : null}
          </div>
        )}
      </main>

      <button className="fab" onClick={openNew}>
        <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
          <path
            d="M12 5v14M5 12h14"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
        New reminder
      </button>

      <dialog
        ref={dialogRef}
        className="sheet"
        onClose={() => setDraft(null)}
        onClick={(e) => {
          if (e.target === dialogRef.current) closeDialog()
        }}
      >
        {draft ? (
          <ReminderForm
            draft={draft}
            onChange={setDraft}
            onSave={saveDraft}
            onCancel={closeDialog}
            onDelete={deleteDraft}
            isNew={isNew}
          />
        ) : null}
      </dialog>

      <div className="toast-stack" aria-live="polite">
        {toasts.map((t) => (
          <div className="toast" key={t.id}>
            <span className="toast-bell" aria-hidden="true">
              <span />
            </span>
            <div>
              <strong>{t.title}</strong>
              <span>{t.body}</span>
            </div>
            <button
              className="toast-close"
              aria-label="Dismiss"
              onClick={() => setToasts((p) => p.filter((x) => x.id !== t.id))}
            >
              ×
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

function isStandalone() {
  return (
    window.matchMedia?.('(display-mode: standalone)').matches ||
    (navigator as unknown as { standalone?: boolean }).standalone === true
  )
}

function minutes(n: number) {
  return n * MINUTE
}

function permissionCopy(p: Permission) {
  switch (p) {
    case 'granted':
      return 'Chime can pop reminders over other windows.'
    case 'denied':
      return 'Blocked here. Alerts will only show inside Chime.'
    case 'unsupported':
      return 'This browser has no notification support.'
    default:
      return 'Not turned on yet.'
  }
}
