import type { ScheduleItem, Tag } from '../types'
import { REPEAT_LABEL, TAG_LABEL } from '../types'
import { fmtDuration, fmtTime, parseLocal, ymd } from '../lib/schedule'

type Props = {
  draft: ScheduleItem
  onChange: (next: ScheduleItem) => void
  onSave: () => void
  onCancel: () => void
  onDelete?: () => void
  isNew: boolean
}

const LEADS = [0, 5, 10, 30, 60]
const TAGS: Tag[] = ['signal', 'ink', 'moss', 'sky']
const REPEATS = Object.keys(REPEAT_LABEL) as (keyof typeof REPEAT_LABEL)[]

const SHORT_REPEAT: Record<keyof typeof REPEAT_LABEL, string> = {
  once: 'Once',
  daily: 'Daily',
  weekdays: 'Weekdays',
  weekly: 'Weekly',
}

export function ReminderForm({
  draft,
  onChange,
  onSave,
  onCancel,
  onDelete,
  isNew,
}: Props) {
  const today = ymd(new Date())
  const set = <K extends keyof ScheduleItem>(key: K, value: ScheduleItem[K]) =>
    onChange({ ...draft, [key]: value })

  const endsAt = (() => {
    if (!draft.date || !draft.time) return null
    const start = parseLocal(draft.date, draft.time)
    if (Number.isNaN(start.getTime())) return null
    return fmtTime(new Date(start.getTime() + draft.duration * 60_000))
  })()

  const valid = draft.title.trim().length > 0 && Boolean(draft.date && draft.time)

  return (
    <form
      className="compose"
      onSubmit={(event) => {
        event.preventDefault()
        if (valid) onSave()
      }}
    >
      <div className="compose-head">
        <h2>{isNew ? 'New reminder' : 'Edit reminder'}</h2>
        <button
          type="button"
          className="ghost close-sheet"
          onClick={onCancel}
          aria-label="Close form"
        >
          Close
        </button>
      </div>

      <label className="field">
        <span className="field-label">What is it?</span>
        <input
          className="input input-title"
          value={draft.title}
          onChange={(e) => set('title', e.target.value)}
          placeholder="Call the dentist"
          maxLength={80}
          autoFocus
          required
        />
      </label>

      <label className="field">
        <span className="field-label">Note</span>
        <input
          className="input"
          value={draft.note}
          onChange={(e) => set('note', e.target.value)}
          placeholder="Bring the insurance card"
          maxLength={160}
        />
      </label>

      <div className="field-row">
        <label className="field">
          <span className="field-label">Date</span>
          <input
            className="input"
            type="date"
            value={draft.date}
            min={isNew ? today : undefined}
            onChange={(e) => set('date', e.target.value || today)}
            required
          />
        </label>
        <label className="field">
          <span className="field-label">Start</span>
          <input
            className="input num"
            type="time"
            value={draft.time}
            onChange={(e) => set('time', e.target.value || '09:00')}
            required
          />
        </label>
      </div>

      <div className="field-row">
        <label className="field">
          <span className="field-label">Lasts</span>
          <select
            className="input"
            value={draft.duration}
            onChange={(e) => set('duration', Number(e.target.value))}
          >
            {[10, 15, 30, 45, 60, 90, 120].map((m) => (
              <option key={m} value={m}>
                {fmtDuration(m)}
              </option>
            ))}
          </select>
        </label>
        <div className="field">
          <span className="field-label">Repeats</span>
          <div className="segmented" role="group" aria-label="Repeat">
            {REPEATS.map((r) => (
              <button
                key={r}
                type="button"
                className="seg"
                aria-pressed={draft.repeat === r}
                onClick={() => set('repeat', r)}
              >
                {SHORT_REPEAT[r]}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="field">
        <span className="field-label">Alert me</span>
        <div className="chips">
          {LEADS.map((m) => (
            <button
              key={m}
              type="button"
              className="chip"
              aria-pressed={draft.lead === m}
              onClick={() => set('lead', m)}
            >
              {m === 0 ? 'On time' : `${m} min before`}
            </button>
          ))}
        </div>
      </div>

      <div className="field">
        <span className="field-label">Marker</span>
        <div className="swatches">
          {TAGS.map((t) => (
            <button
              key={t}
              type="button"
              className={`swatch swatch-${t}`}
              aria-label={TAG_LABEL[t]}
              title={TAG_LABEL[t]}
              aria-pressed={draft.tag === t}
              onClick={() => set('tag', t)}
            />
          ))}
        </div>
      </div>

      {endsAt ? (
        <p className="end-note">
          Ends at {endsAt}
          {draft.repeat !== 'once' ? ` · ${REPEAT_LABEL[draft.repeat]}` : ''}
        </p>
      ) : null}

      <div className="compose-actions">
        <button type="submit" className="primary" disabled={!valid}>
          {isNew ? 'Add reminder' : 'Save changes'}
        </button>
        {!isNew && onDelete ? (
          <button type="button" className="ghost danger" onClick={onDelete}>
            Delete
          </button>
        ) : (
          <button type="button" className="ghost" onClick={onCancel}>
            Cancel
          </button>
        )}
      </div>
    </form>
  )
}
