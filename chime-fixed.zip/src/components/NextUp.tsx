import { fmtCountdown, fmtDuration, fmtTime } from '../lib/schedule'
import type { Occurrence, Tag } from '../types'

export function NextUp({
  occ,
  now,
  count,
}: {
  occ: Occurrence
  now: Date
  count: number
}) {
  const running = occ.start <= now && occ.end > now
  const ms = running ? occ.end.getTime() - now.getTime() : occ.start.getTime() - now.getTime()
  return (
    <section className="ticket" data-tag={occ.item.tag}>
      <div className="ticket-main">
        <p className="ticket-kicker">
          {running ? 'Running now' : 'Next up'}
          {occ.item.repeat !== 'once' ? ` · ${repeatWord(occ.item.repeat)}` : ''}
        </p>
        <h2 className="ticket-title">{occ.item.title}</h2>
        {occ.item.note ? <p className="ticket-note">{occ.item.note}</p> : null}
        <p className="ticket-when">
          <span className="num">{fmtTime(occ.start)}</span>
          <span className="dot" aria-hidden="true" />
          <span className="num">{fmtTime(occ.end)}</span>
          <span className="dot" aria-hidden="true" />
          {fmtDuration(occ.item.duration)}
          <span className="dot" aria-hidden="true" />
          {occ.item.lead === 0 ? 'Alert at start' : `Alert ${occ.item.lead} min before`}
        </p>
      </div>
      <div className="ticket-stub">
        <span className="stub-label">{running ? 'Ends in' : 'Starts in'}</span>
        <strong className="countdown num">{fmtCountdown(ms)}</strong>
        {count > 1 ? (
          <span className="stub-extra">
            {count - 1} more {count === 2 ? 'reminder' : 'reminders'} today
          </span>
        ) : (
          <span className="stub-extra">Timer is live</span>
        )}
      </div>
    </section>
  )
}

function repeatWord(r: 'daily' | 'weekdays' | 'weekly') {
  return r === 'daily' ? 'every day' : r === 'weekdays' ? 'weekdays' : 'weekly'
}

export function TagDot({ tag }: { tag: Tag }) {
  return <span className={`tagdot tagdot-${tag}`} aria-hidden="true" />
}
