export type Repeat = 'once' | 'daily' | 'weekdays' | 'weekly'

export type Tag = 'signal' | 'ink' | 'moss' | 'sky'

export type ScheduleItem = {
  id: string
  title: string
  note: string
  /** Local start date, YYYY-MM-DD */
  date: string
  /** Local start time, HH:MM (24h) */
  time: string
  duration: number
  repeat: Repeat
  /** Minutes before the start to notify. 0 = at start time. */
  lead: number
  tag: Tag
  createdAt: number
  demo?: boolean
}

export type Settings = {
  sound: boolean
}

export type Occurrence = {
  item: ScheduleItem
  key: string
  date: string
  start: Date
  end: Date
  trigger: Date
}

export const TAG_LABEL: Record<Tag, string> = {
  signal: 'Alarm orange',
  ink: 'Ink',
  moss: 'Moss',
  sky: 'Sky',
}

export const REPEAT_LABEL: Record<Repeat, string> = {
  once: 'Once',
  daily: 'Every day',
  weekdays: 'Weekdays',
  weekly: 'Every week',
}
