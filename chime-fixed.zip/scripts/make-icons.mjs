#!/usr/bin/env node
// Renders Chime app icons from one SVG source.
import sharp from 'sharp'
import { mkdir } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { dirname, resolve } from 'node:path'

const here = dirname(fileURLToPath(import.meta.url))
const out = resolve(here, '../public/icons')
await mkdir(out, { recursive: true })

const INK = '#14261c'
const PAPER = '#f6f7ee'
const SIGNAL = '#d8380f'

const ticks = Array.from({ length: 12 }, (_, i) => {
  const angle = (i * 30 * Math.PI) / 180
  const major = i % 3 === 0
  const r1 = major ? 58 : 62
  const r2 = 68
  const w = major ? 5 : 3
  const x1 = 100 + Math.sin(angle) * r1
  const y1 = 100 - Math.cos(angle) * r1
  const x2 = 100 + Math.sin(angle) * r2
  const y2 = 100 - Math.cos(angle) * r2
  return `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${PAPER}" stroke-width="${w}" stroke-linecap="round"/>`
}).join('')

const bell = (sign) => {
  const x = 100 + sign * 62
  const y = 38
  const notch = sign > 0
    ? `M ${x - 18} ${y - 16} L ${x + 13} ${y + 1} L ${x + 18} ${y - 12} Z`
    : `M ${x + 18} ${y - 16} L ${x - 13} ${y + 1} L ${x - 18} ${y - 12} Z`
  return `<g>
    <circle cx="${x}" cy="${y}" r="17" fill="${SIGNAL}"/>
    <path d="${notch}" fill="${INK}"/>
  </g>`
}

const svg = (bleed) => `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 200 200">
  <defs>
    <clipPath id="squircle">
      <rect x="0" y="0" width="200" height="200" rx="${bleed ? 0 : 44}"/>
    </clipPath>
  </defs>
  <g clip-path="url(#squircle)">
    <rect width="200" height="200" fill="${INK}"/>
    <circle cx="100" cy="100" r="72" fill="none" stroke="${PAPER}" stroke-width="9"/>
    ${ticks}
    <line x1="100" y1="100" x2="100" y2="64" stroke="${PAPER}" stroke-width="8" stroke-linecap="round"/>
    <line x1="100" y1="100" x2="130" y2="76" stroke="${SIGNAL}" stroke-width="8" stroke-linecap="round"/>
    <circle cx="100" cy="100" r="7" fill="${PAPER}"/>
    ${bell(-1)}
    ${bell(1)}
  </g>
</svg>`

const sizes = [
  ['icon-192.png', 192, false],
  ['icon-512.png', 512, false],
  ['icon-180.png', 180, false],
]

for (const [name, size, bleed] of sizes) {
  await sharp(Buffer.from(svg(bleed))).resize(size, size).png().toFile(resolve(out, name))
  console.log('wrote', name)
}

// Maskable: full-bleed ink with the clock pulled into the safe zone.
const maskable = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 200 200">
  <rect width="200" height="200" fill="${INK}"/>
  <g transform="translate(100 100) scale(0.78) translate(-100 -100)">
    <circle cx="100" cy="100" r="72" fill="none" stroke="${PAPER}" stroke-width="10"/>
    ${ticks}
    <line x1="100" y1="100" x2="100" y2="64" stroke="${PAPER}" stroke-width="8" stroke-linecap="round"/>
    <line x1="100" y1="100" x2="130" y2="76" stroke="${SIGNAL}" stroke-width="8" stroke-linecap="round"/>
    <circle cx="100" cy="100" r="7" fill="${PAPER}"/>
    ${bell(-1)}
    ${bell(1)}
  </g>
</svg>`

await sharp(Buffer.from(maskable)).resize(512, 512).png().toFile(resolve(out, 'maskable-512.png'))
console.log('wrote maskable-512.png')
