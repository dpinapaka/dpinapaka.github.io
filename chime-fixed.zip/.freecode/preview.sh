cd /home/ubuntu/project && PORT=3000 FREECODE_PREVIEW_HOST=3000-fc.preview.freecode.page vp dev --port 3000 --host 0.0.0.0
